import React from "react";

const TransactionForm = ({ transactionData, onChange }) => {
  const inputFields = [
    { name: "amount", placeholder: "Amount (e.g., 100.00)" },
    { name: "location", placeholder: "Location (e.g., New York)" },
    { name: "time", placeholder: "Time (e.g., 10:30 AM)" },
    { name: "cardHolderName", placeholder: "Cardholder Name" },
    { name: "merchantCategoryCode", placeholder: "Merchant Code" },
    { name: "transactionType", placeholder: "Transaction Type" },
    { name: "ipAddress", placeholder: "IP Address" },
    { name: "deviceType", placeholder: "Device Type" },
    { name: "orderFrequency", placeholder: "Order Frequency" },
    { name: "emailDomain", placeholder: "Email Domain" },
  ];

  return (
    <div>
      {inputFields.map((field) => (
        <div key={field.name} className="input-wrapper">
          <label htmlFor={field.name}>{field.name}:</label>
          <input
            type="text"
            id={field.name}
            name={field.name}
            value={transactionData[field.name]}
            onChange={onChange}
            required
          />
          <span className="watermark">{field.placeholder}</span>
        </div>
      ))}
    </div>
  );
};

export default TransactionForm;