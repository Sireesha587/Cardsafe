import React from "react";

const Alert = ({ onResponse }) => {
  return (
    <div className="alert-container">
      <div className="alert">
        <h3>Possible Fraudulent Transaction!</h3>
        <p>Is this transaction yours?</p>
        <button onClick={() => onResponse(true)}>Yes, it's me</button>
        <button onClick={() => onResponse(false)}>No, it's not me</button>
      </div>
    </div>
  );
};

export default Alert;
