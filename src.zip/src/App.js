import React, { useState } from "react";
import TransactionForm from "./components/TransactionForm";
import Alert from "./components/Alert";
import "./App.css";

const App = () => {
  const [transactionData, setTransactionData] = useState({
    amount: "",
    location: "",
    time: "",
    cardHolderName: "",
    merchantCategoryCode: "",
    transactionType: "",
    ipAddress: "",
    deviceType: "",
    orderFrequency: "",
    emailDomain: "",
  });

  const [isFraudulent, setIsFraudulent] = useState(false);
  const [showAlert, setShowAlert] = useState(false);
  const [message, setMessage] = useState(null);

  const handleInputChange = (e) => {
    setTransactionData({ ...transactionData, [e.target.name]: e.target.value });
  };

  const analyzeTransaction = () => {
    const { amount, location, time, merchantCategoryCode, transactionType, orderFrequency } = transactionData;
    
    let isFraud = false;
    const amountValue = parseFloat(amount);
    if (isNaN(amountValue)) {
      alert("Please enter a valid amount.");
      return;
    }
    if (amountValue > 500000) isFraud = true;

    const currentTime = new Date();
    const [transactionHour, transactionMinute] = time.split(":").map(Number);
    const transactionTime = new Date();
    transactionTime.setHours(transactionHour, transactionMinute, 0, 0);
    const timeDifference = Math.abs(currentTime.getTime() - transactionTime.getTime());
    const timeDifferenceInMinutes = Math.floor(timeDifference / (1000 * 60));

    if (timeDifferenceInMinutes < 10) isFraud = true;

    const commonLocations = ["new york", "los angeles", "chicago", "london", "tokyo"];
    if (!commonLocations.includes(location.toLowerCase())) isFraud = true;

    const commonMerchantCodes = ["5411", "5812", "4814"];
    if (!commonMerchantCodes.includes(merchantCategoryCode)) isFraud = true;

    if (transactionType.toLowerCase() === "international") isFraud = true;

    if (orderFrequency > 10) isFraud = true;

    if (isFraud) {
      setMessage("Possible Fraudulent Transaction!");
      setShowAlert(true);
    } else {
      setMessage("Transaction Proceeded Successfully!");
    }
  };

  const handleAlertResponse = (isMe) => {
    setShowAlert(false);
    setMessage(isMe ? "Transaction Proceeded Successfully!" : "Transaction Cancelled.");
  };

  return (
    <div className="container">
      <h2>Transaction Analyzer</h2>
      <TransactionForm transactionData={transactionData} onChange={handleInputChange} />
      <button className="btn" onClick={analyzeTransaction}>Analyze Transaction</button>
      {showAlert && <Alert onResponse={handleAlertResponse} />}
      {message && <p className={isFraudulent ? "error" : "success"}>{message}</p>}
    </div>
  );
};

export default App;
